"""DJConnect developer onboarding package."""
